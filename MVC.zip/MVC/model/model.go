package model

type User struct { 
    UserName    string   `json:"username"`
    FirstName string 	`json:"firstname"`
    Lastname   string   `json:"lastname"`
	Email   string   `json:"email"`
	Contact   string   `json:"contact"`
	Address   string   `json:"address"`
}
type LoginUser struct { 
    UserName    string   `json:"username"`
    Password   string   `json:"password"`
}