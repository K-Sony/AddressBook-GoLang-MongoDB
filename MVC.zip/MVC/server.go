package main
import (
  "net/http"
  "./controller"
  
)


func main() {

	
	http.HandleFunc("/login", controller.LoginPage)
	http.HandleFunc("/addUser", controller.AddUserPage)
	 http.HandleFunc("/editUser", controller.EditUserHandler)
	 http.HandleFunc("/logout", controller.Logout)

	http.HandleFunc("/home", controller.HomePage)
	http.ListenAndServe(":8080", nil)
	
	
}