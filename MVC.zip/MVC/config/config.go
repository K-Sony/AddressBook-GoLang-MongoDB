// we need to use $ go get github.com/tkanos/gonfig
package config
type Configuration struct {
    Hosts              string
    Database   string
    Collection string
	LoginCollection string
}